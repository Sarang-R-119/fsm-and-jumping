# fsm-and-jumping

Checkout the game at the [link](https://htmlpreview.github.io/?https://github.com/Sarang-R-119/fsm-and-jumping/blob/main/index.html).
